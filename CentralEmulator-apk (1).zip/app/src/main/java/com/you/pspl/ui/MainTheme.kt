package com.you.pspl.ui

import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.you.pspl.data.Game
import com.you.pspl.data.Img
import com.you.pspl.launch.Emu
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

// =====================================================================================
//  Thème « Principal » : tableau de bord sombre (onglets, jeux récents, consoles,
//  émulateurs disponibles, infos du système).
// =====================================================================================

// Zones de focus (manette)
const val MZ_TABS = 0
const val MZ_HERO = 1
const val MZ_RECENT = 2
const val MZ_CONSOLE = 3
const val MZ_CHIPS = 4
const val MZ_GRID = 5
const val MZ_LIST = 6

val MAIN_TABS = listOf("Accueil", "Jeux", "Émulateurs", "Paramètres")

/** Nombre de colonnes de la grille « Jeux » (partagé avec la navigation manette). */
fun mainGridCols(w: Dp): Int = ((w * 0.914f).value / 120f).toInt().coerceIn(3, 8)

private val MnAccent = Color(0xFF3B8CFF)
private val MnAccentSoft = Color(0xFF7FB6FF)
private val MnBorder = Color(0x24FFFFFF)
private val MnDim = Color(0xB3FFFFFF)

/** État de navigation du thème Principal : onglet, zone de focus et position dans la zone. */
class MainState {
    var tab by mutableIntStateOf(0)
    var zone by mutableIntStateOf(MZ_CONSOLE)
    var idx by mutableIntStateOf(0)
    var filter by mutableIntStateOf(0)        // 0 = toutes les consoles, i = platforms[i - 1]

    private fun contentZone(): Int = when (tab) {
        0 -> MZ_HERO
        1 -> MZ_CHIPS
        else -> MZ_LIST
    }

    /** Déplace le focus à la manette. moveList / goTab sont fournis par l'écran d'accueil. */
    fun move(
        n: Nav, recentN: Int, consoleN: Int, filterN: Int, gridN: Int, cols: Int, listSel: Int,
        moveList: (Int) -> Unit, goTab: (Int) -> Unit,
    ) {
        when (zone) {
            MZ_TABS -> when (n) {
                Nav.LEFT -> goTab(tab - 1)
                Nav.RIGHT -> goTab(tab + 1)
                Nav.DOWN -> {
                    zone = contentZone()
                    idx = if (zone == MZ_CHIPS) filter else 0
                }
                else -> {}
            }
            MZ_HERO -> when (n) {
                Nav.UP -> zone = MZ_TABS
                Nav.DOWN -> { zone = MZ_RECENT; idx = 0 }
                else -> {}
            }
            MZ_RECENT -> when (n) {
                Nav.LEFT -> idx = (idx - 1).coerceAtLeast(0)
                Nav.RIGHT -> idx = (idx + 1).coerceAtMost(recentN)        // recentN = « Voir tous »
                Nav.UP -> zone = MZ_HERO
                Nav.DOWN -> { zone = MZ_CONSOLE; idx = idx.coerceAtMost(consoleN - 1) }
                else -> {}
            }
            MZ_CONSOLE -> when (n) {
                Nav.LEFT -> idx = (idx - 1).coerceAtLeast(0)
                Nav.RIGHT -> idx = (idx + 1).coerceAtMost(consoleN - 1)
                Nav.UP -> { zone = MZ_RECENT; idx = idx.coerceAtMost(recentN) }
                else -> {}
            }
            MZ_CHIPS -> when (n) {
                Nav.LEFT -> { filter = (filter - 1).coerceAtLeast(0); idx = filter }
                Nav.RIGHT -> { filter = (filter + 1).coerceAtMost(filterN - 1); idx = filter }
                Nav.UP -> zone = MZ_TABS
                Nav.DOWN -> { if (gridN > 0) { zone = MZ_GRID; idx = 0 } }
                else -> {}
            }
            MZ_GRID -> when (n) {
                Nav.LEFT -> idx = (idx - 1).coerceAtLeast(0)
                Nav.RIGHT -> idx = (idx + 1).coerceAtMost((gridN - 1).coerceAtLeast(0))
                Nav.UP -> { if (idx - cols >= 0) idx -= cols else { zone = MZ_CHIPS; idx = filter } }
                Nav.DOWN -> {
                    if (idx + cols < gridN) idx += cols
                    else if (idx / cols < (gridN - 1) / cols) idx = gridN - 1
                }
                else -> {}
            }
            MZ_LIST -> when (n) {
                Nav.UP -> { if (listSel <= 0) zone = MZ_TABS else moveList(-1) }
                Nav.DOWN -> moveList(1)
                else -> {}
            }
            else -> {}
        }
    }
}

// ------------------------------------------------------------------ Fond

@Composable
fun MainBackground(image: File?) {
    val ctx = LocalContext.current
    val t = rememberInfiniteTransition(label = "mainbg")
    val zoom = t.animateFloat(
        initialValue = 1f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Reverse),
        label = "z",
    )
    val drift = t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "d",
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF04060B), Color(0xFF0A1020), Color(0xFF04060B)))
        )
    ) {
        if (image != null) {
            val req = remember(image) { ImageRequest.Builder(ctx).data(image).size(1920, 1080).build() }
            AsyncImage(
                model = req, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    val z = zoom.value
                    scaleX = z
                    scaleY = z
                    alpha = 0.92f
                },
            )
        }
        // Lueurs bleues qui dérivent lentement
        Canvas(Modifier.fillMaxSize()) {
            val d = drift.value
            val r1 = size.width * 0.5f
            val c1 = Offset(size.width * (0.15f + 0.2f * d), size.height * 0.9f)
            drawCircle(Brush.radialGradient(listOf(Color(0x33305CFF), Color.Transparent), center = c1, radius = r1), r1, c1)
            val r2 = size.width * 0.4f
            val c2 = Offset(size.width * (0.85f - 0.15f * d), size.height * 0.15f)
            drawCircle(Brush.radialGradient(listOf(Color(0x2A00A8FF), Color.Transparent), center = c2, radius = r2), r2, c2)
        }
        // Voile : plus sombre à gauche (lisibilité) et en haut / en bas
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color(0xCC03050A), Color(0x66030509), Color(0x1A000000)))
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xCC000000)))
            )
        )
    }
}

// ------------------------------------------------------------------ Briques de base

/** Apparition douce (fondu + montée) avec un petit décalage : les blocs « arrivent » les uns après les autres. */
@Composable
private fun Modifier.mnRiseIn(key: Any, delayMs: Int): Modifier {
    val k = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        delay(delayMs.toLong())
        k.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        alpha = k.value
        translationY = (1f - k.value) * 18.dp.toPx()
    }
}

/** Carte « verre » : reflet bleu + halo qui pulse + petit rebond quand elle prend le focus. */
@Composable
private fun MnGlass(
    focused: Boolean,
    modifier: Modifier = Modifier,
    radius: Dp = 14.dp,
    selected: Boolean = false,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    val sc by animateFloatAsState(
        if (focused) 1.05f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "fs",
    )
    val glow = if (focused) rememberInfiniteTransition(label = "fg").animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "g",
    ) else null
    val hot = focused || selected
    Box(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                val p = glow?.value ?: 0f
                if (p > 0f) {
                    val e = 8.dp.toPx()
                    drawRoundRect(
                        MnAccent.copy(alpha = 0.30f * p), Offset(-e, -e),
                        Size(this.size.width + 2f * e, this.size.height + 2f * e),
                        CornerRadius(radius.toPx() + e),
                    )
                }
            }
            .clip(shape)
            .background(
                if (hot) Brush.verticalGradient(listOf(Color(0x333B8CFF), Color(0x14FFFFFF)))
                else Brush.verticalGradient(listOf(Color(0x1AFFFFFF), Color(0x0AFFFFFF)))
            )
            .border(if (focused) 1.5.dp else 1.dp, if (hot) MnAccent else MnBorder, shape)
            .tap(onClick),
        content = content,
    )
}

private fun mnInitials(t: String): String = t.trim().take(2).uppercase()

@Composable
private fun MnGameTile(
    g: Game, size: Dp, focused: Boolean,
    iconOf: (Game) -> Img?, bgOf: (Game) -> File?, onClick: () -> Unit,
) {
    MnGlass(focused, Modifier.size(size), 14.dp, onClick = onClick) {
        val bg = bgOf(g)
        if (bg != null) {
            AsyncImage(
                model = bg, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 0.55f },
            )
        }
        val ic = iconOf(g)
        if (ic != null) {
            AsyncImage(
                model = ic.file, contentDescription = g.title, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(8.dp),
            )
        } else {
            Text(
                mnInitials(g.title), color = Color.White, fontSize = (size.value * 0.28f).sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}

private fun mnConsoleColor(p: String): Color = when (p.uppercase()) {
    "PSP" -> Color(0xFF2F9BFF)
    "PS2" -> Color(0xFF7A6BFF)
    "PS3" -> Color.White
    "PS1" -> Color(0xFFB8C0CC)
    "WII", "WII U" -> Color(0xFF39D0FF)
    "GAMECUBE" -> Color(0xFF9D7BFF)
    "DREAMCAST" -> Color(0xFFFF8A3D)
    else -> Color(0xFF8FD3FF)
}

/** Tuile de console : nom stylisé + nombre de jeux (platform == null → tuile « Autres »). */
@Composable
private fun MnConsoleTile(
    platform: String?, count: Int, w: Dp, h: Dp, focused: Boolean, onClick: () -> Unit,
) {
    MnGlass(focused, Modifier.width(w).height(h), 14.dp, onClick = onClick) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            if (platform != null) {
                Text(
                    platform, color = mnConsoleColor(platform),
                    fontSize = if (platform.length > 5) 15.sp else 24.sp,
                    fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (count > 1) "$count jeux" else "$count jeu",
                    color = MnDim, fontSize = 11.sp,
                )
            } else {
                Canvas(Modifier.size(22.dp)) {
                    val s = size.width * 0.44f
                    val g = size.width * 0.12f
                    for (r in 0..1) for (c in 0..1) {
                        drawRoundRect(
                            Color.White, Offset(c * (s + g), r * (s + g)), Size(s, s), CornerRadius(3.dp.toPx()),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Autres", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Barre du haut

@Composable
private fun MnTopBar(
    w: Dp, h: Dp, tab: Int, clock: String, battery: Int,
    onTab: (Int) -> Unit,
) {
    val padX = w * 0.043f
    Box(Modifier.fillMaxWidth().height(h * 0.12f)) {
        // Marque
        Row(
            Modifier.align(Alignment.CenterStart).padding(start = padX),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CatGlyph(CatKind.GAMEPAD, 30.dp)
            Spacer(Modifier.width(10.dp))
            Text("Central Emulator", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        // Onglets
        Row(
            Modifier.align(Alignment.CenterStart).padding(start = maxOf(w * 0.23f, padX + 210.dp)),
            horizontalArrangement = Arrangement.spacedBy(w * 0.035f),
        ) {
            MAIN_TABS.forEachIndexed { i, label ->
                val on = i == tab
                val a by animateFloatAsState(if (on) 1f else 0.6f, label = "ta")
                val uf = animateFloatAsState(if (on) 1f else 0f, label = "tu")
                Text(
                    label, color = Color.White, fontSize = 15.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .graphicsLayer { alpha = a }
                        .drawBehind {
                            val ww = this.size.width * uf.value
                            val x0 = (this.size.width - ww) / 2f
                            drawRoundRect(
                                Brush.horizontalGradient(listOf(MnAccent, MnAccentSoft)),
                                Offset(x0, this.size.height - 2.dp.toPx()),
                                Size(ww, 2.dp.toPx()), CornerRadius(1.dp.toPx()),
                            )
                        }
                        .tap { onTab(i) }
                        .padding(vertical = 8.dp),
                )
            }
        }
        // Droite : recherche, réglages, heure
        Row(
            Modifier.align(Alignment.CenterEnd).padding(end = padX),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Canvas(Modifier.size(20.dp).tap { onTab(1) }) {
                val sw = 2.dp.toPx()
                drawCircle(
                    Color.White, size.minDimension * 0.32f,
                    Offset(size.width * 0.42f, size.height * 0.42f), style = Stroke(sw),
                )
                drawLine(
                    Color.White, Offset(size.width * 0.65f, size.height * 0.65f),
                    Offset(size.width * 0.92f, size.height * 0.92f), sw, StrokeCap.Round,
                )
            }
            Canvas(Modifier.size(20.dp).tap { onTab(3) }) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val r = size.minDimension / 2f
                for (i in 0 until 8) {
                    val a = i * (PI / 4.0)
                    drawLine(
                        Color.White,
                        Offset(c.x + (cos(a) * r * 0.62f).toFloat(), c.y + (sin(a) * r * 0.62f).toFloat()),
                        Offset(c.x + (cos(a) * r * 0.95f).toFloat(), c.y + (sin(a) * r * 0.95f).toFloat()),
                        3.dp.toPx(), StrokeCap.Round,
                    )
                }
                drawCircle(Color.White, r * 0.62f, c, style = Stroke(2.dp.toPx()))
                drawCircle(Color.White, r * 0.22f, c)
            }
            Text("$battery%", color = MnDim, fontSize = 12.sp)
            Text(clock, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ------------------------------------------------------------------ Panneau des émulateurs + infos

private fun mnFmtGb(b: Long): String = String.format(Locale.getDefault(), "%.1f Go", b / 1_073_741_824.0)

/** Vraie icône de l'application de l'émulateur (récupérée sur le téléphone). */
@Composable
private fun MnAppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching {
            val d = ctx.packageManager.getApplicationIcon(pkg)
            val px = 96
            val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(b)
            d.setBounds(0, 0, px, px)
            d.draw(c)
            b.asImageBitmap()
        }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size).clip(RoundedCornerShape(8.dp)))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)))
    }
}

@Composable
private fun MnEmulatorPanel(modifier: Modifier, emus: List<Emu>, maxRows: Int, onOpen: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x24FFFFFF), Color(0x0FFFFFFF))))
            .border(1.dp, MnBorder, shape)
            .tap(onOpen)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            CatGlyph(CatKind.GAMEPAD, 18.dp)
            Spacer(Modifier.width(8.dp))
            Text("Émulateurs disponibles", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        if (emus.isEmpty()) {
            Text("Aucun émulateur détecté", color = MnDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        emus.take(maxRows).forEach { e ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                MnAppIcon(e.pkg, 28.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        e.name.substringBefore(" ("), color = Color.White, fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        e.platforms.joinToString(", ").ifEmpty { "Émulateur" },
                        color = MnDim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("›", color = MnDim, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun MnInfoIcon(kind: Int) {
    Canvas(Modifier.size(20.dp)) {
        val sw = 1.8.dp.toPx()
        when (kind) {
            0 -> {                                   // stockage
                drawRoundRect(
                    Color.White, Offset(size.width * 0.2f, size.height * 0.08f),
                    Size(size.width * 0.6f, size.height * 0.84f), CornerRadius(3.dp.toPx()), style = Stroke(sw),
                )
                for (i in 0..2) {
                    drawLine(
                        Color.White, Offset(size.width * (0.36f + 0.14f * i), size.height * 0.18f),
                        Offset(size.width * (0.36f + 0.14f * i), size.height * 0.34f), sw, StrokeCap.Round,
                    )
                }
            }
            1 -> {                                   // version
                drawCircle(Color.White, size.minDimension * 0.42f, center, style = Stroke(sw))
                drawCircle(Color.White, sw * 0.6f, Offset(size.width / 2f, size.height * 0.32f))
                drawLine(
                    Color.White, Offset(size.width / 2f, size.height * 0.46f),
                    Offset(size.width / 2f, size.height * 0.72f), sw, StrokeCap.Round,
                )
            }
            else -> {                                // android
                val g = Color(0xFF3DDC84)
                drawArc(g, 180f, 180f, true, Offset(size.width * 0.18f, size.height * 0.22f), Size(size.width * 0.64f, size.height * 0.5f))
                drawRoundRect(g, Offset(size.width * 0.18f, size.height * 0.47f), Size(size.width * 0.64f, size.height * 0.38f), CornerRadius(3.dp.toPx()))
                drawCircle(Color(0xFF0A0E16), size.width * 0.04f, Offset(size.width * 0.38f, size.height * 0.4f))
                drawCircle(Color(0xFF0A0E16), size.width * 0.04f, Offset(size.width * 0.62f, size.height * 0.4f))
                drawLine(g, Offset(size.width * 0.3f, size.height * 0.16f), Offset(size.width * 0.38f, size.height * 0.28f), 1.5.dp.toPx(), StrokeCap.Round)
                drawLine(g, Offset(size.width * 0.7f, size.height * 0.16f), Offset(size.width * 0.62f, size.height * 0.28f), 1.5.dp.toPx(), StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun MnInfoCell(kind: Int, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        MnInfoIcon(kind)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, color = MnDim, fontSize = 9.sp, maxLines = 1)
            Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun MnInfoBar(modifier: Modifier) {
    val ctx = LocalContext.current
    val free = remember {
        runCatching { mnFmtGb(StatFs(Environment.getDataDirectory().path).availableBytes) }.getOrDefault("—")
    }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "3.1"
    }
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .clip(shape)
            .background(Color(0x1AFFFFFF))
            .border(1.dp, MnBorder, shape)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        MnInfoCell(0, "Espace libre", free)
        MnInfoCell(1, "Version", version)
        MnInfoCell(2, "Android", Build.VERSION.RELEASE ?: "")
    }
}

// ------------------------------------------------------------------ Onglet Accueil

@Composable
private fun MnHomeTab(
    w: Dp, h: Dp, ms: MainState, platforms: List<String>, games: List<Game>,
    recent: List<Game>, recentIsReal: Boolean, emus: List<Emu>,
    iconOf: (Game) -> Img?, bgOf: (Game) -> File?,
    onTab: (Int) -> Unit, onOpenLibrary: () -> Unit, onPlay: (Game) -> Unit, onConsole: (Int) -> Unit,
) {
    val padX = w * 0.043f
    val tab = 0

    // En-tête
    Row(Modifier.offset(padX, h * 0.14f).mnRiseIn(tab, 0), verticalAlignment = Alignment.CenterVertically) {
        val box = h * 0.138f
        MnGlass(false, Modifier.size(box), 18.dp, onClick = onOpenLibrary) {
            CatGlyph(CatKind.GAMEPAD, box * 0.6f, Modifier.align(Alignment.Center))
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(
                "Central Emulator", color = Color.White,
                fontSize = (h.value * 0.072f).coerceIn(22f, 40f).sp, fontWeight = FontWeight.Light,
            )
            Text("Tous vos jeux, tous vos émulateurs, au même endroit", color = MnDim, fontSize = 12.sp)
        }
    }
    MnGlass(
        ms.zone == MZ_HERO,
        Modifier.offset(padX, h * 0.295f).width(maxOf(w * 0.21f, 190.dp)).height(maxOf(h * 0.075f, 36.dp))
            .mnRiseIn(tab, 80),
        12.dp, onClick = onOpenLibrary,
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Voir la bibliothèque", color = Color.White, fontSize = 14.sp)
            Text("›", color = Color.White, fontSize = 20.sp)
        }
    }

    // Jeux récents
    val tileSize = minOf(h * 0.2f, w * 0.115f)
    Row(Modifier.offset(padX, h * 0.42f).mnRiseIn(tab, 120), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (recentIsReal) "Jeux récents" else "Bibliothèque",
            color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        )
        val fg = if (ms.zone == MZ_RECENT) recent.getOrNull(ms.idx) else null
        if (fg != null) {
            Text(
                "  ·  " + fg.title, color = MnDim, fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = w * 0.45f),
            )
        }
    }
    Row(
        Modifier.offset(padX, h * 0.475f).mnRiseIn(tab, 160),
        horizontalArrangement = Arrangement.spacedBy(w * 0.012f),
    ) {
        recent.forEachIndexed { i, g ->
            MnGameTile(g, tileSize, ms.zone == MZ_RECENT && ms.idx == i, iconOf, bgOf) {
                ms.zone = MZ_RECENT
                ms.idx = i
                onPlay(g)
            }
        }
        MnGlass(
            ms.zone == MZ_RECENT && ms.idx == recent.size, Modifier.size(tileSize), 14.dp,
            onClick = onOpenLibrary,
        ) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("+", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light)
                Text("Voir tous", color = MnDim, fontSize = 11.sp)
            }
        }
    }

    // Choisir un jeu (une tuile par console, puis « Autres »)
    Text(
        "Choisir un jeu", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.offset(padX, h * 0.72f).mnRiseIn(tab, 200),
    )
    val shown = platforms.take(3)
    Row(
        Modifier.offset(padX, h * 0.78f).mnRiseIn(tab, 240),
        horizontalArrangement = Arrangement.spacedBy(w * 0.011f),
    ) {
        shown.forEachIndexed { i, p ->
            MnConsoleTile(p, games.count { it.platform == p }, w * 0.135f, h * 0.155f, ms.zone == MZ_CONSOLE && ms.idx == i) {
                ms.zone = MZ_CONSOLE
                ms.idx = i
                onConsole(i)
            }
        }
        MnConsoleTile(null, 0, w * 0.135f, h * 0.155f, ms.zone == MZ_CONSOLE && ms.idx == shown.size) {
            ms.zone = MZ_CONSOLE
            ms.idx = shown.size
            onConsole(shown.size)
        }
    }

    // Colonne de droite : émulateurs disponibles + infos
    val panelH = h * 0.415f
    val maxRows = ((panelH - 36.dp) / 36.dp).toInt().coerceIn(1, 5)
    MnEmulatorPanel(
        Modifier.offset(w * 0.675f, h * 0.423f).width(w * 0.289f).height(panelH).mnRiseIn(tab, 180),
        emus, maxRows,
    ) { onTab(2) }
    val ibH = maxOf(h * 0.078f, 36.dp)
    MnInfoBar(Modifier.offset(w * 0.675f, h * 0.953f - ibH).width(w * 0.289f).height(ibH).mnRiseIn(tab, 260))
}

// ------------------------------------------------------------------ Onglet Jeux

@Composable
private fun MnGamesTab(
    w: Dp, h: Dp, ms: MainState, platforms: List<String>, list: List<Game>,
    iconOf: (Game) -> Img?, bgOf: (Game) -> File?,
    onFilter: (Int) -> Unit, onPlay: (Game) -> Unit,
) {
    val padX = w * 0.043f
    val tab = 1
    val chips = listOf("Tous") + platforms
    Row(
        Modifier.offset(padX, h * 0.15f).mnRiseIn(tab, 0),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        chips.forEachIndexed { i, label ->
            val picked = ms.filter == i
            MnGlass(
                picked && ms.zone == MZ_CHIPS, Modifier.height(30.dp), 15.dp,
                selected = picked, onClick = { onFilter(i) },
            ) {
                Text(
                    label, color = if (picked) Color.White else MnDim, fontSize = 13.sp,
                    fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(horizontal = 14.dp).align(Alignment.Center),
                )
            }
        }
    }

    val gridW = w * 0.914f
    val cols = mainGridCols(w)
    val gap = 12.dp
    val tile = (gridW - gap * (cols - 1) - 16.dp) / cols
    val gs = rememberLazyGridState()
    LaunchedEffect(ms.idx / cols, ms.zone, ms.filter) {
        if (ms.zone == MZ_GRID) gs.animateScrollToItem(((ms.idx / cols) - 1).coerceAtLeast(0) * cols)
    }
    if (list.isEmpty()) {
        Text(
            "Aucun jeu trouvé", color = MnDim, fontSize = 14.sp,
            modifier = Modifier.offset(padX, h * 0.32f).mnRiseIn(tab, 80),
        )
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = gs,
            modifier = Modifier.offset(padX, h * 0.15f + 40.dp).width(gridW).height(h * 0.85f - 48.dp),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(gap),
            horizontalArrangement = Arrangement.spacedBy(gap),
        ) {
            gridItemsIndexed(list) { i, g ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    MnGameTile(g, tile, ms.zone == MZ_GRID && ms.idx == i, iconOf, bgOf) {
                        ms.zone = MZ_GRID
                        ms.idx = i
                        onPlay(g)
                    }
                    Text(
                        g.title, color = if (ms.zone == MZ_GRID && ms.idx == i) Color.White else MnDim,
                        fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp),
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Onglets Émulateurs / Paramètres

@Composable
private fun MnListTab(
    w: Dp, h: Dp, ms: MainState, items: List<XmbItem>, sel: Int, onItem: (Int) -> Unit,
) {
    val padX = w * 0.043f
    val state = rememberLazyListState()
    LaunchedEffect(sel, ms.zone) {
        if (ms.zone == MZ_LIST) state.animateScrollToItem((sel - 1).coerceAtLeast(0))
    }
    LazyColumn(
        state = state,
        modifier = Modifier.offset(padX, h * 0.16f).width(w * 0.62f).height(h * 0.8f).mnRiseIn(ms.tab, 0),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(6.dp),
    ) {
        itemsIndexed(items) { i, item ->
            MnGlass(
                ms.zone == MZ_LIST && i == sel, Modifier.fillMaxWidth(), 12.dp,
                onClick = { onItem(i) },
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val ic = item.icon
                    val kind = item.kind
                    if (ic != null) {
                        AsyncImage(model = ic.file, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(34.dp))
                    } else if (kind != null) {
                        CatGlyph(kind, 28.dp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (item.subtitle.isNotEmpty()) {
                            Text(item.subtitle, color = MnDim, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Text("›", color = MnDim, fontSize = 18.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Assemblage

@Composable
fun MainLayout(
    w: Dp, h: Dp, ms: MainState,
    platforms: List<String>, games: List<Game>,
    recent: List<Game>, recentIsReal: Boolean, filtered: List<Game>,
    items: List<XmbItem>, sel: Int, emus: List<Emu>,
    iconOf: (Game) -> Img?, bgOf: (Game) -> File?,
    clock: String, battery: Int,
    onTab: (Int) -> Unit, onOpenLibrary: () -> Unit, onPlay: (Game) -> Unit,
    onConsole: (Int) -> Unit, onFilter: (Int) -> Unit, onItem: (Int) -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        when (ms.tab) {
            0 -> MnHomeTab(w, h, ms, platforms, games, recent, recentIsReal, emus, iconOf, bgOf, onTab, onOpenLibrary, onPlay, onConsole)
            1 -> MnGamesTab(w, h, ms, platforms, filtered, iconOf, bgOf, onFilter, onPlay)
            else -> MnListTab(w, h, ms, items, sel, onItem)
        }
        MnTopBar(w, h, ms.tab, clock, battery, onTab)
    }
}
