package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract

/**
 * Un émulateur connu + les consoles pour lesquelles il est recommandé.
 *
 * Pour ajouter un émulateur : il suffit d'ajouter UNE ligne dans [Emulators.known]
 * (le manifest autorise déjà à voir toutes les applications lançables).
 *
 * @param activity  activité à ouvrir directement (null = laisser Android choisir)
 * @param extraKey  nom de l'extra de l'Intent qui reçoit le jeu (ex. "bootPath"), si l'émulateur en veut un
 * @param extraAsPath true = on envoie un chemin de fichier, false = l'URI du jeu
 */
data class Emu(
    val name: String,
    val pkg: String,
    val activity: String? = null,
    val platforms: Set<String> = emptySet(),
    val extraKey: String? = null,
    val extraAsPath: Boolean = false,
)

object Emulators {
    val known = listOf(
        Emu("PPSSPP Gold (PSP)", "org.ppsspp.ppssppgold", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("PPSSPP (PSP)", "org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("DuckStation (PS1)", "com.github.stenzek.duckstation",
            "com.github.stenzek.duckstation.EmulationActivity", setOf("PS1"),
            extraKey = "bootPath", extraAsPath = true),
        Emu("NetherSX2 / AetherSX2 (PS2)", "xyz.aethersx2.android",
            "xyz.aethersx2.android.EmulationActivity", setOf("PS2"),
            extraKey = "bootPath", extraAsPath = true),
        Emu("Dolphin (GameCube / Wii)", "org.dolphinemu.dolphinemu",
            "org.dolphinemu.dolphinemu.activities.EmulationActivity", setOf("GameCube", "Wii"),
            extraKey = "AutoStartFile"),
        Emu("Flycast (Dreamcast)", "com.flycast.emulator",
            "com.flycast.emulator.MainActivity", setOf("Dreamcast")),
    )

    fun isInstalled(ctx: Context, e: Emu): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(e.pkg) != null

    fun installed(ctx: Context): List<Emu> = known.filter { isInstalled(ctx, it) }

    /** Convertit l'URI d'un fichier choisi via le sélecteur Android en chemin (stockage interne / carte SD). */
    private fun toFilePath(uri: Uri): String? = runCatching {
        val id = DocumentsContract.getDocumentId(uri)           // ex. "primary:Games/jeu.iso"
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        if (vol.equals("primary", ignoreCase = true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }.getOrNull()

    private fun base(iso: Uri) = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(iso, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /**
     * La "porte" : lance l'émulateur avec le jeu. false si tout échoue.
     * Essaie dans l'ordre : 1) l'activité précise de l'émulateur (avec son extra si besoin),
     * 2) un simple ouvrir-avec ciblé sur le paquet. Si le 2 échoue aussi, l'écran propose "Autre application…".
     */
    fun launch(ctx: Context, e: Emu, iso: Uri): Boolean {
        if (e.activity != null) {
            val i = base(iso).apply {
                setClassName(e.pkg, e.activity)
                e.extraKey?.let { k ->
                    val v = if (e.extraAsPath) toFilePath(iso) else iso.toString()
                    if (v != null) putExtra(k, v)
                }
            }
            if (runCatching { ctx.startActivity(i) }.isSuccess) return true
        }
        val fallback = base(iso).apply { setPackage(e.pkg) }
        return runCatching { ctx.startActivity(fallback) }.isSuccess
    }

    /** Laisse Android proposer toutes les apps capables d'ouvrir le fichier. */
    fun chooser(ctx: Context, iso: Uri): Boolean {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return runCatching {
            ctx.startActivity(Intent.createChooser(i, "Ouvrir avec…"))
        }.isSuccess
    }

    // ---- Choix mémorisé, une console à la fois (PSP -> PPSSPP, PS2 -> NetherSX2...)
    private fun key(platform: String) = "emu_$platform"

    fun savedPkg(ctx: Context, platform: String): String? =
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString(key(platform), null)

    fun save(ctx: Context, platform: String, pkg: String?) {
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().apply {
            if (pkg == null) remove(key(platform)) else putString(key(platform), pkg)
        }.apply()
    }
}
