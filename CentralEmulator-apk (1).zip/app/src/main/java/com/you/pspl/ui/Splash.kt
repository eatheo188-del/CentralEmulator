package com.you.pspl.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.you.pspl.R
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animation de lancement façon GTA V : éclair, traits de vitesse, logo avec glitch + reflet,
 * faux chargement par étapes (avec « blocages »), puis rideau qui s'ouvre sur l'accueil.
 * Appuyer sur l'écran ou sur une touche de la manette passe l'animation.
 */
object SplashState {
    /** true tant que l'animation est à l'écran (la manette est alors bloquée dans MainActivity). */
    var active by mutableStateOf(true)
    internal var skipCount by mutableStateOf(0)
    fun skip() { skipCount++ }
}

private const val TOTAL_MS = 5600
private const val WIPE_START = 0.92f
private val RED = Color(0xFFFF1E2D)
private val RED_DEEP = Color(0xFF7A0010)

private val STAGES = listOf(
    "INITIALISATION DU SYSTÈME",
    "RECHERCHE DES ÉMULATEURS",
    "CHARGEMENT DE LA BIBLIOTHÈQUE",
    "PRÉPARATION DE L'INTERFACE",
    "PRÊT",
)
private val TIPS = listOf(
    "ASTUCE  —  Choisis ton thème dans Paramètres : PS3, PS4 ou PS5",
    "ASTUCE  —  Touche Options sur un jeu pour changer son image ou son émulateur",
    "ASTUCE  —  Un fond 4K ? Importe-le depuis les Options d'un jeu",
)

// Progression du faux chargement : (moment de l'animation, % atteint). Les paliers plats = « blocages ».
private val KEYS = floatArrayOf(
    0.20f, 0.00f,
    0.30f, 0.13f,
    0.40f, 0.13f,
    0.54f, 0.48f,
    0.60f, 0.48f,
    0.72f, 0.83f,
    0.77f, 0.83f,
    0.88f, 1.00f,
)

private fun fakeProgress(tt: Float): Float {
    if (tt <= KEYS[0]) return 0f
    var i = 0
    while (i < KEYS.size - 2) {
        val t0 = KEYS[i]; val p0 = KEYS[i + 1]
        val t1 = KEYS[i + 2]; val p1 = KEYS[i + 3]
        if (tt < t1) return mix(p0, p1, smooth(rng(tt, t0, t1)))
        i += 2
    }
    return 1f
}

private fun stageOf(p: Float): Int = when {
    p >= 1f -> 4
    p >= 0.83f -> 3
    p >= 0.48f -> 2
    p >= 0.13f -> 1
    else -> 0
}

// ---- petits utilitaires
private fun rng(v: Float, a: Float, b: Float) = ((v - a) / (b - a)).coerceIn(0f, 1f)
private fun smooth(x: Float) = x * x * (3f - 2f * x)
private fun easeOut(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
private fun mix(a: Float, b: Float, k: Float) = a + (b - a) * k
private fun hash(i: Int, salt: Int): Float {
    val x = sin(i * 12.9898f + salt * 78.233f) * 43758.547f
    return x - floor(x)
}
private fun hudAlpha(tt: Float) = smooth(rng(tt, 0.17f, 0.25f)) * (1f - smooth(rng(tt, 0.885f, 0.93f)))

// ---------------------------------------------------------------------------------------------

@Composable
fun LaunchSplash() {
    if (SplashState.active) SplashContent()
}

@Composable
private fun SplashContent() {
    val t = remember { Animatable(0f) }
    val logo = ImageBitmap.imageResource(R.drawable.logo_color)

    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(TOTAL_MS, easing = LinearEasing))
        SplashState.active = false
    }
    // Passer l'animation : on saute directement au rideau final
    val skips = SplashState.skipCount
    LaunchedEffect(skips) {
        if (skips > 0 && t.value >= 0.08f && t.value < WIPE_START) {
            t.snapTo(WIPE_START)
            t.animateTo(1f, tween(480, easing = LinearEasing))
            SplashState.active = false
        }
    }

    val pct by remember { derivedStateOf { (fakeProgress(t.value) * 100f).toInt() } }
    val stage by remember { derivedStateOf { stageOf(fakeProgress(t.value)) } }
    val blink by remember { derivedStateOf { ((t.value * TOTAL_MS) / 420f).toInt() % 2 == 0 } }
    val tip by remember { derivedStateOf { ((t.value * TOTAL_MS) / 1900f).toInt() % TIPS.size } }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onTap = { SplashState.skip() }) }
    ) {
        val mw = maxWidth
        val mh = maxHeight

        // 1) Décor : fond, halo, traits de vitesse, braises, grain… + rideau final
        Canvas(Modifier.fillMaxSize()) { drawStage(t.value) }

        // 2) Logo (couche séparée : le reflet ne touche que le logo)
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        ) { drawLogo(t.value, logo) }

        // 3) Slogan
        Text(
            "TOUS VOS ÉMULATEURS  ·  UN SEUL ENDROIT",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = mh * 0.665f)
                .graphicsLayer {
                    val k = smooth(rng(t.value, 0.34f, 0.46f))
                    alpha = k * (1f - smooth(rng(t.value, 0.89f, 0.94f)))
                    translationY = (1f - k) * 10.dp.toPx()
                },
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 11.sp,
            letterSpacing = 4.sp,
            fontWeight = FontWeight.Medium,
        )

        // 4) Barre de chargement
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = hudAlpha(t.value) }
        ) {
            val p = fakeProgress(t.value)
            val x0 = size.width * 0.05f
            val x1 = size.width * 0.95f
            val y = size.height * 0.925f
            val sw = 2.dp.toPx()
            drawLine(Color(0x2EFFFFFF), Offset(x0, y), Offset(x1, y), sw)
            for (i in 0..10) {
                val x = mix(x0, x1, i / 10f)
                drawLine(Color(0x40FFFFFF), Offset(x, y - 7.dp.toPx()), Offset(x, y - 2.dp.toPx()), 1.dp.toPx())
            }
            if (p > 0.002f) {
                val hx = mix(x0, x1, p)
                drawLine(
                    Brush.horizontalGradient(listOf(RED_DEEP, RED, Color.White), startX = x0, endX = hx),
                    Offset(x0, y), Offset(hx, y), sw * 1.6f,
                )
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.9f), RED.copy(alpha = 0.5f), Color.Transparent),
                        center = Offset(hx, y), radius = 16.dp.toPx(),
                    ),
                    radius = 16.dp.toPx(), center = Offset(hx, y),
                )
            }
        }

        // 5) Textes de chargement + pastille qui tourne
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = mw * 0.05f, end = mw * 0.05f, bottom = mh * 0.115f)
                .graphicsLayer { alpha = hudAlpha(t.value) },
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    STAGES[stage] + if (blink && stage < 4) " _" else "",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                )
                Text(
                    TIPS[tip],
                    color = Color.White.copy(alpha = 0.42f),
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(20.dp)) {
                    val sw = 2.5.dp.toPx()
                    val d = size.minDimension - sw
                    drawCircle(Color(0x33FFFFFF), radius = d / 2f, style = Stroke(sw))
                    rotate((t.value * TOTAL_MS / 3.2f) % 360f) {
                        drawArc(
                            RED, startAngle = 0f, sweepAngle = 110f, useCenter = false,
                            topLeft = Offset(sw / 2f, sw / 2f), size = Size(d, d),
                            style = Stroke(sw, cap = StrokeCap.Round),
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    "$pct%",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Décor
// ---------------------------------------------------------------------------------------------

private fun DrawScope.drawStage(tt: Float) {
    val w = size.width
    val h = size.height
    val wipe = smooth(rng(tt, WIPE_START, 1f))
    if (wipe <= 0f) {
        drawBackdrop(tt, w, h)
        return
    }
    // Rideau final : deux « portes » qui s'écartent depuis le centre et révèlent l'accueil
    val shift = w / 2f * wipe
    translate(left = -shift, top = 0f) {
        clipRect(0f, 0f, w / 2f + 1f, h) { drawBackdrop(tt, w, h) }
    }
    translate(left = shift, top = 0f) {
        clipRect(w / 2f - 1f, 0f, w, h) { drawBackdrop(tt, w, h) }
    }
    val a = 1f - wipe
    for (x in floatArrayOf(w / 2f - shift, w / 2f + shift)) {
        drawLine(RED.copy(alpha = a), Offset(x, 0f), Offset(x, h), strokeWidth = 3.dp.toPx())
        drawLine(Color.White.copy(alpha = a), Offset(x, 0f), Offset(x, h), strokeWidth = 1.dp.toPx())
    }
}

private fun DrawScope.drawBackdrop(tt: Float, w: Float, h: Float) {
    val sec = tt * TOTAL_MS / 1000f
    val cx = w / 2f
    val cy = h * 0.43f

    drawRect(Color(0xFF040405), size = Size(w, h))

    // Halo rouge derrière le logo
    val glow = smooth(rng(tt, 0.08f, 0.32f)) * (0.85f + 0.15f * sin(sec * 2.2f))
    drawRect(
        Brush.radialGradient(
            colors = listOf(RED.copy(alpha = 0.30f * glow), Color.Transparent),
            center = Offset(cx, cy), radius = w * 0.5f,
        ),
        size = Size(w, h),
    )

    // Bande de lumière qui traverse l'écran
    val lk = rng(tt, 0.12f, 0.70f)
    if (lk > 0.001f && lk < 0.999f) {
        val bw = w * 0.22f
        val skew = h * 0.35f
        val x = mix(-bw - skew, w + bw, smooth(lk))
        val p = Path().apply {
            moveTo(x, 0f); lineTo(x + bw, 0f); lineTo(x + bw - skew, h); lineTo(x - skew, h); close()
        }
        drawPath(
            p,
            Brush.horizontalGradient(
                listOf(Color.Transparent, Color(0x1AFFFFFF), Color.Transparent),
                startX = x - skew, endX = x + bw,
            ),
        )
    }

    // Éclair horizontal d'ouverture
    val fl = rng(tt, 0.03f, 0.13f)
    val flFade = 1f - rng(tt, 0.13f, 0.22f)
    if (fl > 0f && flFade > 0f) {
        val half = w * 0.5f * easeOut(fl)
        drawLine(RED.copy(alpha = 0.45f * flFade), Offset(cx - half, cy), Offset(cx + half, cy), strokeWidth = 9.dp.toPx(), cap = StrokeCap.Round)
        drawLine(Color.White.copy(alpha = flFade), Offset(cx - half, cy), Offset(cx + half, cy), strokeWidth = 1.5.dp.toPx())
    }

    // Traits de vitesse
    for (i in 0 until 16) {
        val start = 0.03f + 0.06f * hash(i, 3)
        val k = rng(tt, start, start + 0.15f)
        if (k <= 0f || k >= 1f) continue
        val len = w * (0.12f + 0.30f * hash(i, 2))
        val y = h * (0.08f + 0.84f * hash(i, 1))
        val ltr = i % 2 == 0
        val run = mix(-len, w + len, smooth(k))
        val head = if (ltr) run else w - run
        val tail = if (ltr) head - len else head + len
        val a = 0.55f * sin(k * 3.1416f)
        val c = (if (i % 4 == 0) RED else Color.White).copy(alpha = a)
        drawLine(
            Brush.horizontalGradient(listOf(Color.Transparent, c), startX = tail, endX = head),
            Offset(tail, y), Offset(head, y),
            strokeWidth = (1f + 2f * hash(i, 4)).dp.toPx(),
        )
    }

    // Braises qui montent
    val emberIn = smooth(rng(tt, 0.05f, 0.25f))
    for (i in 0 until 38) {
        val x = w * hash(i, 11) + sin(sec * 0.9f + i) * 10.dp.toPx()
        val y = h * (1f - ((hash(i, 12) + sec * (0.025f + 0.06f * hash(i, 13))) % 1f))
        val r = (0.8f + 2.0f * hash(i, 14)).dp.toPx()
        val a = emberIn * (0.12f + 0.45f * hash(i, 15)) * (0.6f + 0.4f * sin(sec * 3f + i * 2f))
        drawCircle((if (i % 3 == 0) RED else Color.White).copy(alpha = a.coerceIn(0f, 1f)), r, Offset(x, y))
    }

    // Lignes de balayage (effet écran)
    val step = 3.dp.toPx()
    var yy = 0f
    while (yy < h) {
        drawLine(Color(0x0AFFFFFF), Offset(0f, yy), Offset(w, yy), 1f)
        yy += step
    }

    // Vignette
    drawRect(
        Brush.radialGradient(
            0.45f to Color.Transparent, 1f to Color(0xE6000000),
            center = Offset(cx, h * 0.5f), radius = hypot(w, h) * 0.5f,
        ),
        size = Size(w, h),
    )

    // Grain de pellicule
    val rnd = Random((sec * 24f).toInt())
    repeat(150) {
        drawRect(
            Color.White.copy(alpha = 0.03f + 0.07f * rnd.nextFloat()),
            Offset(rnd.nextFloat() * w, rnd.nextFloat() * h), Size(1.6f, 1.6f),
        )
    }

    // Coins façon viseur de caméra
    val mx = w * 0.04f
    val my = h * 0.045f
    val len = 20.dp.toPx()
    val sw = 1.5.dp.toPx()
    val ca = smooth(rng(tt, 0.06f, 0.20f)) * 0.5f * (1f - rng(tt, 0.88f, 0.93f))
    val c = Color.White.copy(alpha = ca)
    drawLine(c, Offset(mx, my), Offset(mx + len, my), sw)
    drawLine(c, Offset(mx, my), Offset(mx, my + len), sw)
    drawLine(c, Offset(w - mx, my), Offset(w - mx - len, my), sw)
    drawLine(c, Offset(w - mx, my), Offset(w - mx, my + len), sw)
    drawLine(c, Offset(mx, h - my), Offset(mx + len, h - my), sw)
    drawLine(c, Offset(mx, h - my), Offset(mx, h - my - len), sw)
    drawLine(c, Offset(w - mx, h - my), Offset(w - mx - len, h - my), sw)
    drawLine(c, Offset(w - mx, h - my), Offset(w - mx, h - my - len), sw)
}

// ---------------------------------------------------------------------------------------------
// Logo : apparition + glitch RVB + reflet
// ---------------------------------------------------------------------------------------------

private fun DrawScope.drawLogo(tt: Float, logo: ImageBitmap) {
    val w = size.width
    val h = size.height
    val sec = tt * TOTAL_MS / 1000f
    val vis = easeOut(rng(tt, 0.10f, 0.27f))
    val out = 1f - smooth(rng(tt, 0.89f, 0.945f))
    val a = vis * out
    if (a <= 0.002f) return

    val logoH = h * 0.40f
    val logoW = logoH * logo.width / logo.height.toFloat()
    val s = mix(1.22f, 1f, vis) * (1f + 0.10f * (1f - out)) * (1f + 0.012f * sin(sec * 2f))
    val dw = (logoW * s).roundToInt()
    val dh = (logoH * s).roundToInt()
    val ox = (w / 2f - dw / 2f).roundToInt()
    val oy = (h * 0.43f - dh / 2f).roundToInt()
    val dst = IntSize(dw, dh)

    // Glitch pendant l'apparition
    val g = 1f - rng(tt, 0.10f, 0.26f)
    val rnd = Random((sec * 30f).toInt())
    val jitter = if (g > 0f) ((rnd.nextFloat() - 0.5f) * 2f * g * logoW * 0.035f).roundToInt() else 0
    val split = (g * logoW * 0.028f).roundToInt()
    if (g > 0.02f) {
        drawImage(
            logo, dstOffset = IntOffset(ox - split + jitter, oy), dstSize = dst,
            alpha = a * 0.6f, colorFilter = ColorFilter.tint(RED), filterQuality = FilterQuality.High,
        )
        drawImage(
            logo, dstOffset = IntOffset(ox + split + jitter, oy), dstSize = dst,
            alpha = a * 0.6f, colorFilter = ColorFilter.tint(Color(0xFF00E5FF)), filterQuality = FilterQuality.High,
        )
    }

    // Logo principal
    drawImage(
        logo, dstOffset = IntOffset(ox, oy), dstSize = dst,
        alpha = a, filterQuality = FilterQuality.High,
    )

    // Tranche décalée (glitch)
    if (g > 0.05f && rnd.nextFloat() < 0.6f) {
        val sy = (rnd.nextFloat() * 0.7f * logo.height).toInt()
        val sh = ((0.08f + 0.12f * rnd.nextFloat()) * logo.height).toInt().coerceIn(2, logo.height - sy)
        val dy = (sy.toFloat() / logo.height * dh).roundToInt()
        val dsh = (sh.toFloat() / logo.height * dh).roundToInt().coerceAtLeast(2)
        val dx = (g * logoW * 0.08f * (rnd.nextFloat() - 0.5f) * 2f).roundToInt()
        drawImage(
            logo,
            srcOffset = IntOffset(0, sy), srcSize = IntSize(logo.width, sh),
            dstOffset = IntOffset(ox + dx, oy + dy), dstSize = IntSize(dw, dsh),
            alpha = a, filterQuality = FilterQuality.High,
        )
    }

    // Reflet qui traverse le logo (uniquement sur les pixels du logo)
    val sk = rng(tt, 0.28f, 0.42f)
    if (sk > 0.001f && sk < 0.999f) {
        val bw = dw * 0.25f
        val x = mix(ox - bw, ox + dw + bw, smooth(sk))
        drawRect(
            Brush.linearGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.95f), Color.Transparent),
                start = Offset(x - bw, oy.toFloat()),
                end = Offset(x + bw, oy + dh * 0.45f),
            ),
            topLeft = Offset(ox.toFloat(), oy.toFloat()),
            size = Size(dw.toFloat(), dh.toFloat()),
            blendMode = BlendMode.SrcAtop,
        )
    }
}
