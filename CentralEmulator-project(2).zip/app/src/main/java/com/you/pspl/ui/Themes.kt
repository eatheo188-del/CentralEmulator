package com.you.pspl.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/** Thème de l'interface : choisi dans Paramètres, mémorisé dans les préférences. */
enum class Theme(val label: String) {
    PS3("PS3"), PS4("PS4"), PS5("PS5");

    fun next(): Theme = entries[(ordinal + 1) % entries.size]

    companion object {
        fun from(name: String?): Theme = entries.firstOrNull { it.name == name } ?: PS3
    }
}

/** Une tuile carrée (icône du jeu, glyphe de catégorie ou initiales), animée vers sa position. */
@Composable
private fun Tile(item: XmbItem, x: Dp, y: Dp, size: Dp, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val ax by animateDpAsState(x, label = "tx")
    val ay by animateDpAsState(y, label = "ty")
    val sz by animateDpAsState(size, label = "ts")
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier.offset(ax, ay).size(sz).clip(shape).background(Color(0x33FFFFFF))
            .then(if (selected) Modifier.border(2.dp, accent, shape) else Modifier)
            .tap(onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (item.icon != null) {
            AsyncImage(
                model = item.icon.file, contentDescription = item.title,
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize(),
            )
        } else if (item.kind != null) {
            CatGlyph(item.kind, sz * 0.55f)
        } else {
            Text(item.title.take(2).uppercase(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Thème PS4 : icônes de catégories en haut, grande tuile sélectionnée puis tuiles à droite. */
@Composable
fun Ps4Layout(
    w: Dp, h: Dp, kinds: List<CatKind>, labels: List<String>, cat: Int,
    items: List<XmbItem>, sel: Int, onCat: (Int) -> Unit, onTap: (Int) -> Unit,
) {
    val big = h * 0.42f
    val small = h * 0.26f
    val gap = 12.dp
    val x0 = w * 0.16f
    val top = h * 0.22f

    Row(
        Modifier.offset(x = w * 0.04f, y = h * 0.05f),
        horizontalArrangement = Arrangement.spacedBy(w * 0.025f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        kinds.forEachIndexed { i, k ->
            Box(Modifier.graphicsLayer { alpha = if (i == cat) 1f else 0.55f }.tap { onCat(i) }) {
                CatGlyph(k, if (i == cat) 38.dp else 28.dp)
            }
        }
    }
    Box(Modifier.offset(y = h * 0.14f).fillMaxWidth(0.62f).height(1.dp).background(Color(0x66FFFFFF)))
    Text(labels.getOrElse(cat) { "" }, color = Color(0xCCFFFFFF), fontSize = 14.sp,
        modifier = Modifier.offset(x = x0, y = top - 26.dp))

    val last = (sel + 8).coerceAtMost(items.size - 1)
    for (j in sel..last) {
        key(cat * 1000 + j) {
            val d = j - sel
            val x = if (d == 0) x0 else x0 + big + gap + (small + gap) * (d - 1)
            val y = if (d == 0) top else top + (big - small) * 0.15f
            Tile(items[j], x, y, if (d == 0) big else small, d == 0, Color(0xFF8FD3FF)) { onTap(j) }
        }
    }
    items.getOrNull(sel)?.let { it ->
        Column(Modifier.offset(x = x0 + big + gap + 8.dp, y = top + big * 0.62f).width(w * 0.5f)) {
            Text(it.title, color = Color.White, fontSize = 26.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(it.subtitle, color = Color(0xE6FFFFFF), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Thème PS5 : onglets + rangée d'icônes en haut, grand visuel du jeu, titre et bouton « Jouer ». */
@Composable
fun Ps5Layout(
    w: Dp, h: Dp, labels: List<String>, cat: Int,
    items: List<XmbItem>, sel: Int, onCat: (Int) -> Unit, onTap: (Int) -> Unit,
) {
    val x0 = w * 0.04f
    // Voile sombre (haut et bas) pour que le texte reste lisible sur le visuel du jeu
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xAA000000), Color(0x00000000), Color(0xCC000000)))
        )
    )
    Row(Modifier.offset(x = x0, y = h * 0.05f), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        labels.forEachIndexed { i, l ->
            Text(
                l, color = Color.White, fontSize = 15.sp,
                fontWeight = if (i == cat) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.graphicsLayer { alpha = if (i == cat) 1f else 0.55f }.tap { onCat(i) },
            )
        }
    }

    val icon = h * 0.11f
    val selIcon = h * 0.15f
    val gap = 8.dp
    val cy = h * 0.14f + icon / 2f
    val lo = (sel - 2).coerceAtLeast(0)
    val hi = (sel + 12).coerceAtMost(items.size - 1)
    for (j in lo..hi) {
        key(cat * 1000 + j) {
            val selX = x0 + (icon + gap) * (sel - lo)
            val x = when {
                j < sel -> x0 + (icon + gap) * (j - lo)
                j == sel -> selX
                else -> selX + selIcon + gap + (icon + gap) * (j - sel - 1)
            }
            val s = if (j == sel) selIcon else icon
            Tile(items[j], x, cy - s / 2f, s, j == sel, Color.White) { onTap(j) }
        }
    }
    items.getOrNull(sel)?.let { it ->
        Column(Modifier.offset(x = x0, y = h * 0.50f).width(w * 0.6f)) {
            Text(it.title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(it.subtitle, color = Color(0xCCFFFFFF), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color.White).tap { onTap(sel) }
                    .padding(horizontal = 30.dp, vertical = 10.dp)
            ) {
                Text(if (it.badge != null) "Jouer" else "Ouvrir", color = Color.Black,
                    fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
