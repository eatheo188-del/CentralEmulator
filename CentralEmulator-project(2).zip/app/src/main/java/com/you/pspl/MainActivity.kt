package com.you.pspl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.you.pspl.data.Game
import com.you.pspl.data.GameScanner
import com.you.pspl.data.ScanResult
import com.you.pspl.ui.CrashScreen
import com.you.pspl.ui.EmptyScreen
import com.you.pspl.ui.HomeScreen
import com.you.pspl.ui.LoadingScreen
import com.you.pspl.ui.Nav
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlinx.coroutines.flow.MutableSharedFlow

class MainActivity : ComponentActivity() {
    private var games by mutableStateOf(listOf<Game>())
    private var errors by mutableStateOf(listOf<String>())
    private var loading by mutableStateOf(false)
    private var scanned by mutableStateOf(false)
    private var crash by mutableStateOf<String?>(null)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private val navFlow = MutableSharedFlow<Nav>(extraBufferCapacity = 16)

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.edit().putString("tree", uri.toString()).apply()
            load(uri)
        }
    }

    private fun pickFolder() { folderPicker.launch(null) }

    private fun load(uri: Uri) {
        loading = true
        thread {
            val result = try {
                GameScanner.scan(this, uri)
            } catch (t: Throwable) {
                ScanResult(emptyList(), listOf("Analyse impossible : ${t.message ?: t.javaClass.simpleName}"))
            }
            runOnUiThread {
                games = result.games
                errors = result.errors
                scanned = true
                loading = false
            }
        }
    }

    /** Relit tous les jeux (les images personnalisées sont conservées). */
    private fun refresh() {
        val saved = prefs.getString("tree", null)
        if (saved == null) { pickFolder(); return }
        GameScanner.clearCache(this)
        load(Uri.parse(saved))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Plein écran immersif (barres masquées, réapparaissent en glissant depuis le bord)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        CrashLog.install(this)
        crash = CrashLog.read(this)
        prefs.getString("tree", null)?.let { load(Uri.parse(it)) }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    val c = crash
                    when {
                        c != null -> CrashScreen(c) {
                            CrashLog.clear(this@MainActivity)
                            crash = null
                        }
                        loading -> LoadingScreen()
                        games.isEmpty() -> EmptyScreen(scanned, errors) { pickFolder() }
                        else -> HomeScreen(
                            games = games,
                            errors = errors,
                            nav = navFlow,
                            onChangeFolder = { pickFolder() },
                            onRefresh = { refresh() },
                        )
                    }
                }
            }
        }
    }

    // ---- Manette (PS4 / DualShock 4, Xbox...) :
    //      croix = naviguer, ✕ = valider, ○ = retour, △ ou Options = menu Options, L1/R1 = catégorie
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val n = when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_BUTTON_L1 -> Nav.LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_BUTTON_R1 -> Nav.RIGHT
                KeyEvent.KEYCODE_DPAD_UP -> Nav.UP
                KeyEvent.KEYCODE_DPAD_DOWN -> Nav.DOWN
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> Nav.SELECT
                KeyEvent.KEYCODE_BUTTON_B -> Nav.BACK
                KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_X,
                KeyEvent.KEYCODE_BUTTON_START -> Nav.OPTIONS
                else -> null
            }
            if (n != null) {
                val repeatable = n == Nav.LEFT || n == Nav.RIGHT || n == Nav.UP || n == Nav.DOWN
                if (e.repeatCount == 0 || repeatable) navFlow.tryEmit(n)
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // Joystick gauche + croix directionnelle (certaines manettes l'envoient comme un axe)
    private var latchX = 0
    private var latchY = 0
    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE) {
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val x = if (abs(hx) > 0.5f) hx else e.getAxisValue(MotionEvent.AXIS_X)
            val y = if (abs(hy) > 0.5f) hy else e.getAxisValue(MotionEvent.AXIS_Y)
            latchX = edge(x, latchX, Nav.LEFT, Nav.RIGHT)
            latchY = edge(y, latchY, Nav.UP, Nav.DOWN)
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    private fun edge(v: Float, latched: Int, neg: Nav, pos: Nav): Int {
        val s = when {
            v > 0.6f -> 1
            v < -0.6f -> -1
            abs(v) < 0.3f -> 0
            else -> latched
        }
        if (s != latched && s != 0) navFlow.tryEmit(if (s > 0) pos else neg)
        return s
    }
}
