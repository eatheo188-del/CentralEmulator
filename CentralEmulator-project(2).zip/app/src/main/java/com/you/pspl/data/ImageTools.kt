package com.you.pspl.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object ImageTools {
    const val W_4K = 3840
    const val H_4K = 2160

    /**
     * Convertit l'image choisie en vrai 4K (3840×2160, JPEG) : rotation EXIF corrigée,
     * rognage centré en 16:9, puis agrandissement ou réduction lissés.
     * Un agrandissement ne crée pas de détails en plus : une petite image sera 4K mais restera douce.
     * Renvoie false en cas d'échec (le fichier d'origine peut alors être copié tel quel).
     */
    fun saveAs4k(cr: ContentResolver, uri: Uri, out: File, quality: Int = 85): Boolean {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val boundsIn = cr.openInputStream(uri) ?: return false
            boundsIn.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            val orientation = runCatching {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val swap = deg == 90f || deg == 270f
            val ow = if (swap) bounds.outHeight else bounds.outWidth
            val oh = if (swap) bounds.outWidth else bounds.outHeight

            // On ne décode pas plus gros que nécessaire (évite de saturer la mémoire avec une photo de 50 Mpx)
            val cropW = if (ow * 9 > oh * 16) oh * 16 / 9 else ow
            var sample = 1
            while (cropW / (sample * 2) >= W_4K) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decodeIn = cr.openInputStream(uri) ?: return false
            var bmp: Bitmap = decodeIn.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false

            if (deg != 0f) {
                val rotated = Bitmap.createBitmap(
                    bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true,
                )
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }

            // Rognage 16:9 centré
            val cw: Int
            val ch: Int
            if (bmp.width * 9 > bmp.height * 16) { ch = bmp.height; cw = ch * 16 / 9 } else { cw = bmp.width; ch = cw * 9 / 16 }
            val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
            if (cropped !== bmp) bmp.recycle()

            val big = if (cw == W_4K && ch == H_4K) cropped
            else Bitmap.createScaledBitmap(cropped, W_4K, H_4K, true)
            if (big !== cropped) cropped.recycle()

            val ok = FileOutputStream(out).use { big.compress(Bitmap.CompressFormat.JPEG, quality, it) }
            big.recycle()
            return ok
        } catch (t: Throwable) {          // y compris OutOfMemoryError sur les petits téléphones
            return false
        }
    }
}
