package com.you.pspl.launch

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.DocumentsContract

/** Application installée pouvant être utilisée comme émulateur. */
data class Emu(
    val name: String,
    val pkg: String,
    val activity: String? = null,
    val platforms: Set<String> = emptySet(),
    val extraKey: String? = null,
    val extraAsPath: Boolean = false,
)

object Emulators {
    // Métadonnées spécifiques pour les émulateurs dont le lancement est connu.
    private val known = listOf(
        Emu("PPSSPP Gold (PSP)", "org.ppsspp.ppssppgold", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("PPSSPP (PSP)", "org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity", setOf("PSP")),
        Emu("DuckStation (PS1)", "com.github.stenzek.duckstation", "com.github.stenzek.duckstation.EmulationActivity", setOf("PS1"), extraKey = "bootPath", extraAsPath = true),
        Emu("NetherSX2 / AetherSX2 (PS2)", "xyz.aethersx2.android", "xyz.aethersx2.android.EmulationActivity", setOf("PS2"), extraKey = "bootPath", extraAsPath = true),
        Emu("Dolphin (GameCube / Wii)", "org.dolphinemu.dolphinemu", "org.dolphinemu.dolphinemu.activities.EmulationActivity", setOf("GameCube", "Wii"), extraKey = "AutoStartFile"),
        Emu("Flycast (Dreamcast)", "com.flycast.emulator", "com.flycast.emulator.MainActivity", setOf("Dreamcast")),
    )

    /**
     * Retourne toutes les applications ayant une icône de lancement, pas seulement
     * celles codées à l'avance. Android limite la visibilité aux applications lançables.
     */
    @Suppress("DEPRECATION")
    fun installed(ctx: Context): List<Emu> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .asSequence()
            .mapNotNull { resolve ->
                val info = resolve.activityInfo ?: return@mapNotNull null
                val pkg = info.packageName
                if (pkg == ctx.packageName) return@mapNotNull null
                val preset = known.firstOrNull { it.pkg == pkg }
                if (preset != null) preset
                else Emu(
                    name = runCatching { info.loadLabel(pm).toString() }.getOrDefault(pkg),
                    pkg = pkg,
                    platforms = guessPlatforms(pkg, info.name),
                )
            }
            .distinctBy { it.pkg }
            .sortedWith(compareBy<Emu>({ it.platforms.isEmpty() }, { it.name.lowercase() }))
            .toList()
    }

    private fun guessPlatforms(pkg: String, activity: String): Set<String> {
        val s = (pkg + " " + activity).lowercase()
        return buildSet {
            if ("rpcs3" in s || "ps3" in s || "a3e" in s) add("PS3")
            if ("vita3k" in s || "psvita" in s) add("PS Vita")
            if ("ppsspp" in s) add("PSP")
            if ("duckstation" in s) add("PS1")
            if ("aethersx2" in s || "nethersx2" in s || "play!" in s) add("PS2")
            if ("dolphin" in s) { add("GameCube"); add("Wii") }
            if ("flycast" in s) add("Dreamcast")
        }
    }

    private fun toFilePath(uri: Uri): String? = runCatching {
        val id = DocumentsContract.getDocumentId(uri)
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        if (vol.equals("primary", ignoreCase = true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }.getOrNull()

    private fun base(iso: Uri) = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(iso, "application/octet-stream")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Essaie l'activité spécifique, puis l'ouverture du fichier, puis l'écran d'accueil de l'application. */
    fun launch(ctx: Context, e: Emu, iso: Uri): Boolean {
        if (e.activity != null) {
            val i = base(iso).apply {
                setClassName(e.pkg, e.activity)
                e.extraKey?.let { k ->
                    val v = if (e.extraAsPath) toFilePath(iso) else iso.toString()
                    if (v != null) putExtra(k, v)
                }
            }
            if (runCatching { ctx.startActivity(i) }.isSuccess) return true
        }
        val openFile = base(iso).apply { setPackage(e.pkg) }
        if (runCatching { ctx.startActivity(openFile) }.isSuccess) return true

        // Certaines applications n'acceptent pas directement les ISO : on peut au
        // moins ouvrir l'émulateur. Il faudra alors sélectionner le jeu dans celui-ci.
        val launch = ctx.packageManager.getLaunchIntentForPackage(e.pkg)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return launch != null && runCatching { ctx.startActivity(launch) }.isSuccess
    }

    fun chooser(ctx: Context, iso: Uri): Boolean {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(iso, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return runCatching { ctx.startActivity(Intent.createChooser(i, "Ouvrir avec…")) }.isSuccess
    }

    private fun key(platform: String) = "emu_$platform"

    fun savedPkg(ctx: Context, platform: String): String? =
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString(key(platform), null)

    fun save(ctx: Context, platform: String, pkg: String?) {
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().apply {
            if (pkg == null) remove(key(platform)) else putString(key(platform), pkg)
        }.apply()
    }
}
